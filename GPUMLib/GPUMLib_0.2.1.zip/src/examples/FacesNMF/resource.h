//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FacesNMF.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FACESNMF_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_SLIDER_ZOOM                 1000
#define IDC_SLIDER_IMAGE                1001
#define IDC_SLIDER_ZOOM2                1002
#define IDC_SLIDER_ITERATIONS           1002
#define IDC_STATIC_ITERATION            1004
#define IDC_CHECK_USE_CUDA              1005
#define IDC_STATIC_TIME                 1006
#define IDC_COMBO_METHOD                1007
#define IDC_BUTTON_RND                  1008
#define IDC_STATIC_RANK                 1009
#define IDC_EDIT_RANK                   1010
#define IDC_EDIT_TRAIN_FOLDER           1011
#define IDC_EDIT_TEST_FOLDER            1012
#define IDC_BUTTON_UPDATE_IMAGES        1013
#define IDC_EDIT_TOL                    1015
#define ID_TRAIN_TEST                   1016
#define IDC_BUTTON1                     1017
#define IDC_BUTTON_SAVE                 1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
